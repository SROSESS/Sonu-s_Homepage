$("document").ready(
    function() {
      $(".dress").draggable({ revert:true });           
      $(".avatar").droppable({
        accept: '.dress',
        drop: function(event, ui) {
          $(this).addClass("dropped");
          $(this).append($(ui.draggable));
       console.log("dropped");   
         }
      });
      $(".grid").droppable({
        accept: '.dress',
        drop: function(event, ui) {
          $(this).append($(ui.draggable));
         }
      });
});

$(".dropped").click(
  function(){
    $(this).append($(".grid"));
    console.log("dress clicked");
 }
);